<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "be81c97f774c6a57c8e455824e1c4a90");
define("PRIVATE_KEY", "6e91b17c4dcce625203b10e10e0dba0d");



 ?>