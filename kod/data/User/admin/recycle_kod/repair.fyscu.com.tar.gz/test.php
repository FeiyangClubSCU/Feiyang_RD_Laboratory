<?php
//register_shutdown_function(function(){ var_dump(error_get_last()); });die();

// import flight framework
require_once 'lib/flight/Flight.php';

// load config
require_once 'config.php';

echo(strtotime(date('Y-m-d')." - 2 days"));